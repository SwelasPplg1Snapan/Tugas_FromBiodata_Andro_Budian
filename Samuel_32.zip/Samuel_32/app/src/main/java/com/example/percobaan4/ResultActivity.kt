package com.example.percobaan4

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val tvHasil = findViewById<TextView>(R.id.tvHasil)

        val nama = intent.getStringExtra("NAMA")
        val alamat = intent.getStringExtra("ALAMAT")
        val tanggal = intent.getStringExtra("TANGGAL")
        val gender = intent.getStringExtra("GENDER")
        val agama = intent.getStringExtra("AGAMA")

        val hasil = """
            Nama       : $nama
            Alamat     : $alamat
            Tanggal    : $tanggal
            Gender     : $gender
            Agama      : $agama
        """.trimIndent()

        tvHasil.text = hasil
    }
}
