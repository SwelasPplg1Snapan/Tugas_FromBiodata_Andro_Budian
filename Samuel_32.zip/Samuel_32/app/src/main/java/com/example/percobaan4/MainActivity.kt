package com.example.percobaan4

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var etNama: EditText
    private lateinit var etAlamat: EditText
    private lateinit var etTanggal: EditText
    private lateinit var rgGender: RadioGroup
    private lateinit var spinnerAgama: Spinner
    private lateinit var btnSimpan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Hubungkan ke komponen
        etNama = findViewById(R.id.etNama)
        etAlamat = findViewById(R.id.etAlamat)
        etTanggal = findViewById(R.id.etTanggal)
        rgGender = findViewById(R.id.rgGender)
        spinnerAgama = findViewById(R.id.spinnerAgama)
        btnSimpan = findViewById(R.id.btnSimpan)

        // Isi spinner agama
        val listAgama = arrayOf("Islam", "Kristen", "Katolik", "Hindu", "Budha", "Konghucu")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, listAgama)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerAgama.adapter = adapter

        // DatePicker untuk tanggal lahir
        etTanggal.setOnClickListener {
            val c = Calendar.getInstance()
            val year = c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)

            val dp = DatePickerDialog(this, { _, y, m, d ->
                etTanggal.setText("$d/${m+1}/$y")
            }, year, month, day)
            dp.show()
        }

        // Tombol simpan
        btnSimpan.setOnClickListener {
            val nama = etNama.text.toString()
            val alamat = etAlamat.text.toString()
            val tanggal = etTanggal.text.toString()
            val selectedGenderId = rgGender.checkedRadioButtonId
            val agama = spinnerAgama.selectedItem.toString()

            // Validasi
            if (nama.isEmpty() || alamat.isEmpty() || tanggal.isEmpty() || selectedGenderId == -1) {
                Toast.makeText(this, "Semua field harus diisi!", Toast.LENGTH_SHORT).show()
            } else {
                val gender = findViewById<RadioButton>(selectedGenderId).text.toString()

                // Kirim ke ResultActivity
                val intent = Intent(this, ResultActivity::class.java)
                intent.putExtra("NAMA", nama)
                intent.putExtra("ALAMAT", alamat)
                intent.putExtra("TANGGAL", tanggal)
                intent.putExtra("GENDER", gender)
                intent.putExtra("AGAMA", agama)
                startActivity(intent)
            }
        }
    }
}
